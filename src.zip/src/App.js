import logo from './logo.svg';
import './App.css';
import Cart from './Components/Cart';
import styles from "./Component/Cart.css"

import Example from './Tailwind/Tailwind';
function App() {
  return (
    <div className="App">
       <Cart/>
      {/* <Example/> */}
    </div>
  );
}

export default App;
